<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sản phẩm chi tiết</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/trang_chu.css">
    <link rel="stylesheet" href="../bootstraps/bootstrap-5.1.3-dist/css/bootstrap.css">
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
            <div class="container-fluid">
                <a class="navbar-branch" href="">
                    <img src="../image/logo.png" alt="" width="100px">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item px-5"><a class="nav-link" href="">Trang chủ</a></li>
                        <li class="nav-item px-5"><a class="nav-link" href="">Sản phẩm</a></li>
                        <li class="nav-item px-5"><a class="nav-link" href="">Tin tức</a></li>
                        <li class="nav-item px-5"><a class="nav-link" href="">Liên hệ & Hỗ trợ</a></li>
                    </ul>
                </div>
                    <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3">
                        <input type="search" class="form-control form-control-dark" placeholder="Search..."
                            aria-label="Search">
                    </form>
                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                        <button type="button" class="btn btn-light">Login</button>
                    </div>
                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                        <button type="button" class="btn btn-warning">Sign-up</button>
                    </div>
            </div>
        </nav>
        <div class="row ">
            <div class="row col-9" style="height: 600px;" >
                <div class="col">
                    <img src="../image/san_pham.jpg" alt="" width="450px">
                </div>
                <div class="col-6">
                    <h5 class="card-title spct">ÁO PHÔNG DIOR ERODED</h5>
                    <h6 class="card-text">$76.0 - $150.0</h6>
                    <div class="row mb-2 mt-4">
                        <div class="row cols-4">
                            <div class="col-2">
                                <p>Màu</p>
                            </div>
                            <div class="col">
                                <input type="checkbox" class="btn-check" id="btn-check" autocomplete="off">
                                <label class="btn btn-secondary" style="width: 100%;" for="btn-check">Xanh mint</label>
                            </div>
                            <div class="col">
                                <input type="checkbox" class="btn-check" id="btn-check" autocomplete="off">
                                <label class="btn btn-secondary" style="width: 100%;" for="btn-check">Đen</label>
                            </div>
                            <div class="col">
                                <input type="checkbox" class="btn-check" id="btn-check" autocomplete="off">
                                <label class="btn btn-secondary" style="width: 100%;" for="btn-check">Đỏ</label>
                            </div>
                        </div>
                        <div class="row cols-4">
                            <div class="col-2">
                                
                            </div>
                            <div class="col">
                                <input type="checkbox" class="btn-check" id="btn-check" autocomplete="off">
                                <label class="btn btn-secondary" style="width: 100%;" for="btn-check">Xám</label>
                            </div>
                            <div class="col">
                                <input type="checkbox" class="btn-check" id="btn-check" autocomplete="off">
                                <label class="btn btn-secondary" style="width: 100%;" for="btn-check">Vàng</label>
                            </div>
                            <div class="col">
                                <input type="checkbox" class="btn-check" id="btn-check" autocomplete="off">
                                <label class="btn btn-secondary" style="width: 100%;" for="btn-check">Xanh lá</label>
                            </div>
                        </div>
                    </div>
                    <div class="row cols-5 mt-4">
                        <div class="col-2">
                            <p>Size</p>
                        </div>
                        <div class="form-check col">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">S</label>
                        </div>
                        <div class="form-check col">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">M</label>
                        </div>
                        <div class="form-check col">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">L</label>
                        </div>
                        <div class="form-check col">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">XL</label>
                        </div>
                    </div>
                    <div class="row cols-2 mt-4">
                        <div class="col-3">
                            <p>Số lượng</p>
                        </div>
                        <div class="col">
                            <div class="btn-group " role="group" aria-label="Basic example">
                                <button type="button" class="btn btn-dark">-</button>
                                <input type="text" class="form-control form-control-dark btn btn-dark" placeholder="1">
                                <button type="button" class="btn btn-dark">+</button>
                            </div>
                        </div>
                    </div>
                    <div class="row cols-2 mt-4">
                        <div class="col">
                            <button type="button" style="width: 100%;" class="btn btn-dark">Thêm giỏ hàng</button>
                        </div>
                        <div class="col">
                            <button type="button" style="width: 100%;" class="btn btn-warning">Mua ngay</button>
                        </div>
                    </div>
                </div>
                <h5 class="btn btn-dark mt-4" style="height: 40px;width:480px">Mô tả sản phẩm</h5>
                <span style="width: 70%;">
                    * THÔNG TIN CHI TIẾT SẢN PHẨM 
                  - Chất liệu: chất len dệt kim dày dặn
                  - Đường may tinh tế, tỉ mỉ trong từng chi tiết 
                  - Kiểu dáng: Áo gile 
                  - Xuất xứ: Hàng tự thiết kế và sản xuất tại Việt Nam 
                  - Màu Sắc: Trắng, Nâu, Be
                  - Size:  dưới 60kg</span>
                <h5 class="btn btn-dark mt-4" style="height: 40px;width:480px">Bình luận</h5>
                <textarea class="form-control mb-2 " id="exampleFormControlTextarea1" rows="3" placeholder="Comment"></textarea>
                <div class="row cols-2 mb-4">
                    <div class="col-10"></div>
                    <div class="col">
                        <button type="button" style="width: 100%;" class="btn btn-warning">Đăng</button>
                    </div>
                </div>
                <hr>
                <div class="mb-3" style="width: 75%;">
                    <div class="row g-0">
                      <div class="col-md-1 mt-2  rounded-circle" style="max-width: 50px;">
                        <img src="../image/san_pham.jpg"  style="max-width: 40px; max-height: 40px;" class="img-fluid rounded-start rounded-circle" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h6 class="card-title">Lê Thanh Bình</h6>
                          <p class="card-text"><small class="text-muted">sản phẩm đẹp</small></p>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
            <div class="col mt-6">
                <div class="card" >
                    <div class="card-header text-white bg-dark">
                        <span>DANH MỤC SẢN PHẨM</span>
                    </div>
                    <ul class="list-group list-group-flush">
                    <li class="list-group-item">Đồ Nam</li>
                    <li class="list-group-item">Đồ Nữ</li>
                    <li class="list-group-item">Đồ Trẻ Em</li>
                    <li class="list-group-item">Đồ Công Sở</li>
                    <li class="list-group-item">Đồ Ngủ<li>
                    </ul>
                </div>
                <div class="card " >
                    <div class=" card-header text-white bg-dark">
                        <span >SẢN PHẨM CÙNG LOẠI</span>
                    </div>
                    <ul class="list-group list-group-flush">
                        <div class="row yeu_thich">
                            <div class="col-md-2">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                        <div class="row  yeu_thich">
                            <div class="col-md-2">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                        <div class="row  yeu_thich">
                            <div class="col-md-2 ">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                        <div class="row yeu_thich">
                            <div class="col-md-2">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                        <div class="row yeu_thich">
                            <div class="col-md-2">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                        <div class="row  yeu_thich">
                            <div class="col-md-2">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text  yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                        <div class="row yeu_thich">
                            <div class="col-md-2">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                        <div class="row yeu_thich">
                            <div class="col-md-2">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                        <div class="row yeu_thich">
                            <div class="col-md-2">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                        <div class="row yeu_thich">
                            <div class="col-md-2">
                            <img src="../image/san_pham.jpg" width="50px" class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col">
                            <div class="card-body">
                                <p class="card-text yt">ÁO PHÔNG DIOR ERODED</p>
                            </div>
                            </div>
                        </div>
                    </ul>
                </div>
            </div>
        </div>
        <footer class=" footer row row-cols-7 py-5 my-5 border-top">
            <div class="col-1">
    
            </div>
            <div class="col">
                <img src="../image/logo.png" alt="" width="200px">
                <div class="row">
                    <div class="col"><img src="../image/face.png" alt="" width="30px"></div>
                    <div class="col"><img src="../image/tw.png" alt="" width="23px"></div>
                    <div class="col"><img src="../image/ig.png" alt="" width="30px"></div>
                    <div class="col"><img src="../image/ytb.png" alt="" width="30px"></div>
                </div>
            </div>
    
            <div class="col">
    
            </div>
    
            <div class="col">
                <h5>About Us</h5>
                <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted"><h6>Address</h6></a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Store & Office</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Jl. Setrasari Kulon III, No. 10-12, </a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Sukarasa, Sukasari, Bandung, Jawa Barat,</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Indonesia 40152</a></li>
                </ul>
            </div>
            <div class="col">
    
            </div>
            <div class="col">
                <h5>Get in touch</h5>
                <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted"><h6>Phone    022-20277564</h6></a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted"><h6>Service     0811-233-8899</h6></a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Center</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted"><h6>Customer     0811-235-9988</h6></a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Service</a></li>
                </ul>
            </div>
            <div class="col-1">
    
            </div>
        </footer>
    </div>
</body>
</html>