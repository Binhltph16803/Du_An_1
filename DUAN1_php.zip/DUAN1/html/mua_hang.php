<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mua hàng</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/trang_chu.css">
    <link rel="stylesheet" href="../bootstraps/bootstrap-5.1.3-dist/css/bootstrap.css">
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
            <div class="container-fluid">
                <a class="navbar-branch" href="">
                    <img src="../image/logo.png" alt="" width="100px">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item px-5"><a class="nav-link" href="">Trang chủ</a></li>
                        <li class="nav-item px-5"><a class="nav-link" href="">Sản phẩm</a></li>
                        <li class="nav-item px-5"><a class="nav-link" href="">Tin tức</a></li>
                        <li class="nav-item px-5"><a class="nav-link" href="">Liên hệ & Hỗ trợ</a></li>
                    </ul>
                </div>
                    <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3">
                        <input type="search" class="form-control form-control-dark" placeholder="Search..."
                            aria-label="Search">
                    </form>
                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                        <button type="button" class="btn btn-light">Login</button>
                    </div>
                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                        <button type="button" class="btn btn-warning">Sign-up</button>
                    </div>
            </div>
        </nav>
        <div class=" btn btn-dark mt-2 pt-4" style="width: 100%;">
            <h5 style="width: 30%;"><img src="../image/dia_chi_mh.png" style="max-width: 30px;" alt="">Địa chỉ nhận hàng</h5>
            <div class="row">
                <div class="col">
                    <p>Lê Thanh Bình  (+84)01234567890</p>
                </div>
                <div class="col">
                    <p>Xuân Phương - Nam Từ Liêm - Hà Nội</p>
                </div>
                <div class="col-3">
                    <button type="button" class="btn btn-warning">Thay đổi</button>
                </div>
            </div>
        </div>
        <div class="btn btn-warning mt-4" style="width: 100%;">
            <div class="row pt-3">
                <div class="col-7">
                    <h6 style="width: 20%;"><img src="../image/icon_sp.png" style="max-width: 30px;" alt="">Sản phẩm</h6>
                </div>
                <div class="col">
                    <p>Đơn giá</p>
                </div>
                <div class="col">
                    <p>Số lượng</p>
                </div>
                <div class="col">
                    <p>Thành tiền</p>
                </div>
            </div>
        </div>
        <div class="row cols-6 mt-2">
            <div class="col-2">
                <img src="../image/san_pham.jpg" alt="" style="max-width: 150px;">
            </div>
            <div class="col-3 m-auto">
                <p>Áo bomber nam nữ,Áo sweater hoodie nam nữ from rộng unisex nỉ bông K43</p>
            </div>
            <div class="col-2 m-auto">
                <p class="card-text"><small class="text-muted">Phân loại hàng: size S, màu trắng</small></p>
            </div>
            <div class="col text-center m-auto">
                <p>$76</p>
            </div>
            <div class="col text-center m-auto">
                <div class="btn-group " role="group" aria-label="Basic example">
                    <button type="button" class="btn btn-dark">-</button>
                    <input type="text" class="form-control form-control-dark btn btn-dark" placeholder="1">
                    <button type="button" class="btn btn-dark">+</button>
                </div>
            </div>
            <div class="col text-center m-auto red">
                <h5>$76</h5>
            </div>
        </div>
        <hr>
        <div class="row cols-3 mt-2">
            <div class="col-1">
                <p>Lời nhắn:</p>
            </div>
            <div class="col-5">
                <input type="text" class="form-control form-control-dark" style="max-width: 300px;" placeholder="Lời nhắn cho Người bán">
            </div>
            <div class="col-3">
                <p class="card-text"><small class="text-muted">Thanh toán khi nhận hàng</small></p>
            </div>
            <div class="col">
                <p>Phí vận chuyển:</p>
                <p>Tổng thanh toán:</p>
            </div>
            <div class="col">
                <p>$1</p>
                <h5 class="red">$77</h5>
            </div>
        </div>
        <div class="row cols-2 mt-2">
            <div class="col-10"></div>
            <div class="col">
                <button type="button" style="width: 70%;" class="btn btn-warning">Mua hàng</button>
            </div>
        </div>

        <footer class=" footer row row-cols-7 py-5 my-5 border-top">
            <div class="col-1">
    
            </div>
            <div class="col">
                <img src="../image/logo.png" alt="" width="200px">
                <div class="row">
                    <div class="col"><img src="../image/face.png" alt="" width="30px"></div>
                    <div class="col"><img src="../image/tw.png" alt="" width="23px"></div>
                    <div class="col"><img src="../image/ig.png" alt="" width="30px"></div>
                    <div class="col"><img src="../image/ytb.png" alt="" width="30px"></div>
                </div>
            </div>
    
            <div class="col">
    
            </div>
    
            <div class="col">
                <h5>About Us</h5>
                <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted"><h6>Address</h6></a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Store & Office</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Jl. Setrasari Kulon III, No. 10-12, </a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Sukarasa, Sukasari, Bandung, Jawa Barat,</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Indonesia 40152</a></li>
                </ul>
            </div>
            <div class="col">
    
            </div>
            <div class="col">
                <h5>Get in touch</h5>
                <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted"><h6>Phone    022-20277564</h6></a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted"><h6>Service     0811-233-8899</h6></a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Center</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted"><h6>Customer     0811-235-9988</h6></a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Service</a></li>
                </ul>
            </div>
            <div class="col-1">
    
            </div>
        </footer>
    </div>
</body>
</html>